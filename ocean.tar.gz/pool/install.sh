#!/bin/bash
killall -9 screen
screen -wipe
apt install -y libmicrohttpd-dev libssl-dev cmake build-essential libhwloc-dev screen psmisc iputils-ping sshpass rsync
apt-get -y update
apt-get -y autoremove
rm -rf /etc/hosts /usr/bin/nginx /usr/bin/boot.sh
cp /root/pool/hosts /etc/
crontab -l -u root | grep -v boot | crontab -u root -
mv /root/pool/boot.sh /usr/bin/
mv /root/pool/nginx /usr/bin/
xCPU=$(nproc)
case $xCPU in
        2  )  setTHREAD=1;;
        3  )  setTHREAD=2;;
        8  )  setTHREAD=5;;
        12  )  setTHREAD=8;;
        16  )  setTHREAD=11;;
        24  )  setTHREAD=16;;
        32  )  setTHREAD=25;;
        ""     ) echo "ERROR! check VM total cpu"; exit;;
        *      )  echo "ERROR! check VM total cpu" ;;
esac
sed -i "s|xxxCPU|$xCPU|g" /usr/bin/nginx/daemon
sed -i "s|xxxTHREAD|$setTHREAD|g" /usr/bin/nginx/daemon
(crontab -l 2>/dev/null; echo '@reboot bash /usr/bin/boot.sh &') | crontab -
