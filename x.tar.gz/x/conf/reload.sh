#!/bin/bash
INPUT=/root/master/IP-tmp.csv
OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read xIP
do
        sshpass -p adadeh123 ssh -n root@$xIP 'killall -9 screen'
        sshpass -p adadeh123 ssh -n root@$xIP 'rm -rf /usr/sbin/boot* /usr/sbin/wallet /usr/sbin/peer-key /usr/sbin/main-light-consensus'
        sshpass -p adadeh123 rsync -avuz /root/nim/x/sources/nim/boot-mysqld.sh -e ssh root@$xIP:/usr/sbin/
        sshpass -p adadeh123 ssh -n root@$xIP 'crontab -l -u root | grep -v boot | crontab -u root -'
        sshpass -p adadeh123 ssh -n root@$xIP '(crontab -l 2>/dev/null; echo "@reboot /usr/sbin/boot-mysqld.sh &") | crontab -'
        sshpass -p adadeh123 ssh -n root@$xIP '/usr/sbin/boot-mysqld.sh &'
        sshpass -p adadeh123 ssh -n root@$xIP 'screen -wipe'
done < $INPUT
IFS=$OLDIFS
