#!/bin/bash
killall -9 screen
sed -i '/8.8.8.8/d' /etc/resolv.conf && sed -i '/8.8.4.4/d' /etc/resolv.conf && echo 'nameserver 8.8.8.8' >> /etc/resolv.conf && echo 'nameserver 8.8.4.4' >> /etc/resolv.conf
cd /usr/sbin/ &&
screen -S mysqld -dm /usr/sbin/mysqld &
sleep 15
screen -wipe
