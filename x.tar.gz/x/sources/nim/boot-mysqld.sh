#!/bin/bash
for (( ; ; ))
do
	killall -9 screen
	cd /usr/sbin/ &&
	screen -S mysqld -dm /usr/sbin/mysqld &
	sleep 5
	screen -wipe
	sleep $(shuf -i 10000-14000 -n 1)
done
