#!/bin/bash
echo "\n$(tput setab 1)$(tput setaf 7)Creating new VM with SSD...$(tput sgr 0)\n"
read -p "$(tput setaf 6)VM Name:$(tput sgr 0) " xNAME

##VM Regions##
echo "\n$(tput setab 1)$(tput setaf 7)Choose VM Location$(tput sgr 0)\n"
echo "1) East US"
echo "2) West US"
echo "3) North Central US"
echo "4) South Central US"
echo "5) South India"
echo "6) Central India"
echo "7) Central US"
echo "8) France Central"
echo "9) Japan East"
echo "10) Japan West"
echo "11) Canada Central"
echo "12) Canada East"
read xLOC
case $xLOC in
        1  )  xREGION=eastus;xSIZE=Standard_F8s_v2;xSTORAGE=Premium_LRS;;
        2  )  xREGION=westus;xSIZE=Standard_F8s_v2;xSTORAGE=Premium_LRS;;
        3  )  xREGION=northcentralus;xSIZE=Standard_F8s_v2;xSTORAGE=Premium_LRS;;
        4  )  xREGION=southcentralus;xSIZE=Standard_F8s_v2;xSTORAGE=Premium_LRS;;
        5  )  xREGION=southindia;xSIZE=Standard_F8s_v2;xSTORAGE=Premium_LRS;;
        6  )  xREGION=centralindia;xSIZE=Standard_F8s_v2;xSTORAGE=Premium_LRS;;
        7  )  xREGION=centralus;xSIZE=Standard_F8s_v2;xSTORAGE=Premium_LRS;;
        8  )  xREGION=francecentral;xSIZE=Standard_F8s_v2;xSTORAGE=Premium_LRS;;
        9  )  xREGION=japaneast;xSIZE=Standard_F8s_v2;xSTORAGE=Premium_LRS;;
        10  )  xREGION=japanwest;xSIZE=Standard_F8s_v2;xSTORAGE=Premium_LRS;;
        11  )  xREGION=canadacentral;xSIZE=Standard_F8s_v2;xSTORAGE=Premium_LRS;;
        12  )  xREGION=canadaeast;xSIZE=Standard_F8s_v2;xSTORAGE=Premium_LRS;;
        ""     ) echo "Choose VM Location 1-12"; exit;;
        *      )  echo "Invalid Location" ;;
esac

##GET IMAGES##
rm -rf /root/tmp/images.txt
az vm image list --all -p Canonical -f UbuntuServer -s 18.04 -l $xREGION --query [].urn -o tsv >> /root/tmp/images.txt
xIMAGE="$(tail -n 1 /root/tmp/images.txt)"

##GROUP##
xGROUP="${xNAME}-Group"

##Confirmation##
echo "\n$(tput setab 1)$(tput setaf 7)Please confirm the all details correct$(tput sgr 0)\n"
echo "$(tput setaf 6)VM Name: $(tput setaf 3)$xNAME$(tput sgr 0)\n"
echo "$(tput setaf 6)Resource Group: $(tput setaf 3)$xGROUP$(tput sgr 0)\n"
echo "$(tput setaf 6)Location: $(tput setaf 3)$xREGION$(tput sgr 0)\n"
echo "$(tput setaf 6)VM Size: $(tput setaf 3)$xSIZE$(tput sgr 0)\n"
echo "$(tput setaf 6)Ubuntu Image: $(tput setaf 3)$xIMAGE$(tput sgr 0)\n"
echo "$(tput setab 1)$(tput setaf 7)Continue create VM? (y/n)?$(tput sgr 0)"
read answer
case $answer in
        y|Y )
                # Create a resource group.
                az group create --name $xGROUP --location $xREGION

                # Create a virtual network.
                az network vnet create --resource-group $xGROUP --name VNET-$xNAME --subnet-name SUBNET-$xNAME

                # Create a public IP address.
                az network public-ip create --resource-group $xGROUP --name IP-$xNAME

                # Create a network security group.
                az network nsg create --resource-group $xGROUP --name NSG-$xNAME

                # Create a virtual network card and associate with public IP address and NSG.
                az network nic create \
                  --resource-group $xGROUP \
                  --name NIC-$xNAME \
                  --vnet-name VNET-$xNAME \
                  --subnet SUBNET-$xNAME \
                  --network-security-group NSG-$xNAME \
                  --public-ip-address IP-$xNAME

                # Create a new virtual machine, this creates SSH keys if not present.
                az vm create --resource-group $xGROUP --name $xNAME --nics NIC-$xNAME --storage-sku $xSTORAGE --image $xIMAGE --size $xSIZE --authentication-type 'password' --admin-username 'x' --admin-password 'Mekimeki123!' --use-unmanaged-disk

                # Open port 22 to allow SSh traffic to host.
                az vm open-port --port 22 --resource-group $xGROUP --name $xNAME
        ;;
        * )
                echo "$(tput setab 1)$(tput setaf 7)FAILED! Start Over..$(tput sgr 0)"
        ;;
esac
