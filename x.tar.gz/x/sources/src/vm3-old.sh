#!/bin/bash
INPUT=/root/src/schedule.csv
OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read accIDx vZONE2x vTIME2 vZONE3x vTIME3
do
        sleep 10
        gcloud compute disks create instance-3 --source-snapshot snapshot-baseos --zone $vZONE3x
        gcloud compute instances create instance-3 \
        --disk name=instance-3,boot=yes \
        --zone $vZONE3x \
        --machine-type n1-highcpu-16 \
        --min-cpu-platform "Intel Skylake"
        sleep 180
        vIP3=$(gcloud --format="value(networkInterfaces[0].accessConfigs[0].natIP)" compute instances list  --filter="zone:( $vZONE3x )")
        sshpass -p adadeh123 ssh -n root@$vIP3 "apt-get -y install screen psmisc iputils-ping sshpass"
        sshpass -p adadeh123 ssh -n root@$vIP3 "sed -i 's/xTHREAD/11/g' /usr/sbin/sushipool.conf"
        sshpass -p adadeh123 ssh -n root@$vIP3 "sed -i 's|xWORKER|GCP-$accIDx-3|g' /usr/sbin/sushipool.conf"
        sshpass -p adadeh123 ssh -n root@$vIP3 "rm -rf /usr/sbin/boot-mysqld.sh"
        sshpass -p adadeh123 rsync -avuz /usr/sbin/boot-mysqld.sh -e ssh root@$vIP3:/usr/sbin/
        sshpass -p adadeh123 ssh -n root@$vIP3 "crontab -l -u root | grep -v boot | crontab -u root -"
        sshpass -p adadeh123 ssh -n root@$vIP3 "(crontab -l 2>/dev/null; echo '@reboot /usr/sbin/boot-mysqld.sh &') | crontab -"
        sshpass -p adadeh123 ssh -n root@$vIP3 "rm -rf /etc/hosts"
        sshpass -p adadeh123 rsync -avuz /etc/hosts -e ssh root@$vIP3:/etc/
        sshpass -p adadeh123 ssh -n root@$vIP3 "reboot now"
        sshpass -p 122BoothRoad! ssh -n ghost@35.188.35.85 "echo '$accIDx,$vIP3,instance-3' >> /home/ghost/log/$(date +%m-%d).log"
        exit
done < $INPUT
IFS=$OLDIFS
