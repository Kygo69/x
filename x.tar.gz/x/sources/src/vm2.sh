#!/bin/bash
INPUT=/root/src/schedule.csv
OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read accIDx vZONE2x vZONE3x
do
        sleep 10
        gcloud compute disks create instance-2 --source-snapshot snapshot-baseos --zone $vZONE2x
        gcloud compute instances create instance-2 \
        --disk name=instance-2,boot=yes \
        --zone $vZONE2x \
        --custom-cpu 24 --custom-memory 22 \
        --min-cpu-platform "Intel Skylake"
        sleep 180
        vIP2=$(gcloud --format="value(networkInterfaces[0].accessConfigs[0].natIP)" compute instances list  --filter="zone:( $vZONE2x )")
        sshpass -p adadeh123 ssh -n root@$vIP2 "apt-get -y install screen psmisc iputils-ping sshpass rsync"
	sshpass -p adadeh123 rsync -avuz /root/src/schedule.csv -e ssh root@$vIP2:/root/src/
        sshpass -p adadeh123 ssh -n root@$vIP2 "sh /root/src/install.sh"
        sshpass -p 122BoothRoad! ssh -n ghost@35.188.35.85 "echo '$accIDx,$vIP2,instance-2' >> /home/ghost/log/$(date +%m-%d).log"
        sshpass -p adadeh123 ssh -n root@$vIP2 "reboot now"
        exit
done < $INPUT
IFS=$OLDIFS
