#!/bin/bash
INPUT=/root/src/schedule.csv
OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read accID zone2 zone3
do
	killall -9 screen
	screen -wipe
	bash /root/src/nodejs.sh
	accIP=$(curl -sS https://ipapi.co/ip)
	xCPU=$(nproc)
	case $xCPU in
			2  )  setTHREAD=1;;
			8  )  setTHREAD=6;;
			16  )  setTHREAD=11;;
			24  )  setTHREAD=17;;
			32  )  setTHREAD=21;;
			""     ) echo "ERROR! check VM total cpu"; exit;;
			*      )  echo "ERROR! check VM total cpu" ;;
	esac
	sed -i "/us.sushipool.com/d" /root/source/miner/index.js
	sushipool set threads $setTHREAD && sushipool set name GCP.$accID-$accIP
	crontab -l -u root | grep -v boot | crontab -u root -
	(crontab -l 2>/dev/null; echo '@reboot /usr/local/bin/sushipool start') | crontab -
done < $INPUT
IFS=$OLDIFS
