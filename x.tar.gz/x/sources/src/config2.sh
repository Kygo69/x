#!/bin/bash
accID=$(cat /root/src/id)
crontab -l -u root | grep -v boot | crontab -u root -
(crontab -l 2>/dev/null; echo "@reboot /usr/sbin/boot-mysqld.sh &") | crontab -
sed -i "s|xWORKER|GCP-$accID-2|g" /usr/sbin/sushipool.conf
sed -i "s|xTHREAD|16|g" /usr/sbin/sushipool.conf
