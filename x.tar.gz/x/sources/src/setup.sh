#!/bin/bash
read -p "$(tput setab 1)$(tput setaf 7)Account ID #: $(tput sgr 0) " accID
vZONE=$(curl -sH Metadata-Flavor:Google http://metadata/computeMetadata/v1/instance/zone | cut -d/ -f4)
case $vZONE in
        us-east1-b  )  vZONE2=$(shuf -n 1 /root/src/asia-east.txt);vZONE3=$(shuf -n 1 /root/src/central.txt);;
        us-east1-c  )  vZONE2=$(shuf -n 1 /root/src/central.txt);vZONE3=$(shuf -n 1 /root/src/asia-southeast.txt);;
        us-east1-d  )  vZONE2=$(shuf -n 1 /root/src/asia-east.txt);vZONE3=$(shuf -n 1 /root/src/central.txt);;
        us-west1-a  )  vZONE2=$(shuf -n 1 /root/src/central.txt);vZONE3=$(shuf -n 1 /root/src/east.txt);;
        us-west1-b  )  vZONE2=$(shuf -n 1 /root/src/east.txt);vZONE3=$(shuf -n 1 /root/src/central.txt);;
        us-west1-c  )  vZONE2=$(shuf -n 1 /root/src/central.txt);vZONE3=$(shuf -n 1 /root/src/east.txt);;
        us-central1-a  )  vZONE2=$(shuf -n 1 /root/src/asia-southeast.txt);vZONE3=$(shuf -n 1 /root/src/east.txt);;
        us-central1-b  )  vZONE2=$(shuf -n 1 /root/src/east.txt);vZONE3=$(shuf -n 1 /root/src/asia-east.txt);;
        us-central1-c  )  vZONE2=$(shuf -n 1 /root/src/asia-southeast.txt);vZONE3=$(shuf -n 1 /root/src/east.txt);;
        us-central1-f  )  vZONE2=$(shuf -n 1 /root/src/east.txt);vZONE3=$(shuf -n 1 /root/src/asia-east.txt);;
esac
xCPU=$(nproc)
case $xCPU in
        2  )  setTHREAD=1;;
        8  )  setTHREAD=5;;
        16  )  setTHREAD=11;;
        24  )  setTHREAD=16;;
        32  )  setTHREAD=21;;
        ""     ) echo "ERROR! check VM total cpu"; exit;;
        *      )  echo "ERROR! check VM total cpu" ;;
esac

killall -9 screen
screen -wipe
bash /root/src/nodejs.sh
accIP=$(curl -sS https://ipapi.co/ip)
sed -i "/us.sushipool.com/d" /root/source/miner/index.js
sushipool set threads $setTHREAD && sushipool set name GCP.$accID-$accIP
crontab -l -u root | grep -v boot | crontab -u root -
(crontab -l 2>/dev/null; echo '@reboot /usr/local/bin/sushipool start') | crontab -

echo -n "" > /root/src/schedule.csv
echo "$accID,$vZONE2,$vZONE3" >> /root/src/schedule.csv
gcloud compute instances list
echo "================================"
echo "       ### VM CONFIG ###"
echo "================================"
echo "Account ID #     :  $accID"
echo "instance-1 Zone  :  $vZONE"
echo "================================"
echo "VM #2 Zone       :  $vZONE2"
echo "---------------------------"
echo "VM #3 Zone       :  $vZONE3"
echo "================================"
echo "Jika ada yang tidak sesuai dan ingin diperbaiki, ulangi -> xsetup"
vIP1=$(gcloud --format="value(networkInterfaces[0].accessConfigs[0].natIP)" compute instances list  --filter="zone:( $vZONE )")
sshpass -p 122BoothRoad! ssh -n ghost@35.188.35.85 "echo '$accID,$vIP1,instance-1' >> /home/ghost/log/$(date +%m-%d).log"
