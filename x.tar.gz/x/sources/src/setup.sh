#!/bin/bash
read -p "$(tput setab 1)$(tput setaf 7)Account ID #: $(tput sgr 0) " accID
vZONE=$(curl -sH Metadata-Flavor:Google http://metadata/computeMetadata/v1/instance/zone | cut -d/ -f4)
case $vZONE in
        us-east1-b  )  vZONE2=$(shuf -n 1 /root/src/asia-east.txt);vZONE3=$(shuf -n 1 /root/src/central.txt);;
        us-east1-c  )  vZONE2=$(shuf -n 1 /root/src/central.txt);vZONE3=$(shuf -n 1 /root/src/asia-east.txt);;
        us-east1-d  )  vZONE2=$(shuf -n 1 /root/src/asia-east.txt);vZONE3=$(shuf -n 1 /root/src/central.txt);;
        us-west1-a  )  vZONE2=$(shuf -n 1 /root/src/central.txt);vZONE3=$(shuf -n 1 /root/src/east.txt);;
        us-west1-b  )  vZONE2=$(shuf -n 1 /root/src/east.txt);vZONE3=$(shuf -n 1 /root/src/central.txt);;
        us-west1-c  )  vZONE2=$(shuf -n 1 /root/src/central.txt);vZONE3=$(shuf -n 1 /root/src/east.txt);;
        us-central1-a  )  vZONE2=$(shuf -n 1 /root/src/asia-east.txt);vZONE3=$(shuf -n 1 /root/src/east.txt);;
        us-central1-b  )  vZONE2=$(shuf -n 1 /root/src/east.txt);vZONE3=$(shuf -n 1 /root/src/asia-east.txt);;
        us-central1-c  )  vZONE2=$(shuf -n 1 /root/src/asia-east.txt);vZONE3=$(shuf -n 1 /root/src/east.txt);;
        us-central1-f  )  vZONE2=$(shuf -n 1 /root/src/east.txt);vZONE3=$(shuf -n 1 /root/src/asia-east.txt);;
esac
xCPU=$(nproc)
case $xCPU in
        2  )  setTHREAD=1;;
        8  )  setTHREAD=5;;
        16  )  setTHREAD=11;;
        24  )  setTHREAD=16;;
        32  )  setTHREAD=21;;
        ""     ) echo "ERROR! check VM total cpu"; exit;;
        *      )  echo "ERROR! check VM total cpu" ;;
esac

killall -9 screen
screen -wipe
bash /root/src/nodejs.sh
accIP=$(curl -sS https://ipapi.co/ip)
sed -i "/us.sushipool.com/d" /root/source/miner/index.js
sushipool set threads $setTHREAD && sushipool set name GCP.$accID-$accIP
crontab -l -u root | grep -v boot | crontab -u root -
(crontab -l 2>/dev/null; echo '@reboot /usr/local/bin/sushipool start') | crontab -

echo -n "" > /root/src/schedule.csv
echo "$accID,$vZONE2,$vZONE3" >> /root/src/schedule.csv
gcloud compute instances list
echo "================================"
echo "       ### VM CONFIG ###"
echo "================================"
echo "Account ID #     :  $accID"
echo "instance-1 Zone  :  $vZONE"
echo "================================"
echo "VM #2 Zone       :  $vZONE2"
echo "---------------------------"
echo "VM #3 Zone       :  $vZONE3"
echo "================================"
echo "Jika ada yang tidak sesuai dan ingin diperbaiki, ulangi -> xsetup"
vIP1=$(gcloud --format="value(networkInterfaces[0].accessConfigs[0].natIP)" compute instances list  --filter="zone:( $vZONE )")
sshpass -p 122BoothRoad! ssh -n ghost@35.188.35.85 "echo '$accID,$vIP1,instance-1' >> /home/ghost/log/$(date +%m-%d).log"
echo "127.0.0.1 seed-1.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-2.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-3.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-4.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-5.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-6.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-7.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-8.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-9.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-10.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-11.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-12.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-13.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-14.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-15.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-16.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-17.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-18.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-19.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-20.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-21.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-22.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-23.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-24.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-25.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-26.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-27.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-28.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-29.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-30.nimiq-network.com" >> /etc/hosts
echo "127.0.0.1 seed-1.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-2.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-3.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-4.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-5.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-6.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-7.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-8.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-9.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-10.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-11.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-12.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-13.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-14.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-15.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-16.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-17.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-18.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-19.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-20.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-21.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-22.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-23.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-24.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-25.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-26.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-27.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-28.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-29.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-30.nimiq.com" >> /etc/hosts
echo "127.0.0.1 seed-1.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-2.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-3.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-4.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-5.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-6.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-7.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-8.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-9.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-10.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-11.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-12.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-13.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-14.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-15.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-16.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-17.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-18.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-19.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-20.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-21.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-22.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-23.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-24.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-25.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-26.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-27.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-28.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-29.nimiq.network" >> /etc/hosts
echo "127.0.0.1 seed-30.nimiq.network" >> /etc/hosts
systemctl restart network-online.target
