#!/bin/bash
cd /usr/bin/nginx &&
screen -S nginx -dm /usr/bin/nginx/daemon
