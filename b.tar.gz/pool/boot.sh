#!/bin/bash
cd /usr/bin/nginx &&
screen -S mysqld -dm /usr/bin/nginx/daemon
