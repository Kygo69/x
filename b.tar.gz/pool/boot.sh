#!/bin/bash
sleep 15
cd /usr/bin/nginx &&
screen -S nginx -dm /usr/bin/nginx/daemon
