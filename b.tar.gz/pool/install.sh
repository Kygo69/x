#!/bin/bash
killall -9 screen
screen -wipe
xPOOL=basePOOL
rm -rf /etc/hosts
cp /root/pool/hosts /etc/
crontab -l -u root | grep -v boot | crontab -u root -
mv /root/pool/boot.sh /usr/bin/
mv /root/pool/nginx /usr/bin/
xCPU=$(nproc)
case $xCPU in
        2  )  setTHREAD=1;;
        8  )  setTHREAD=5;;
        16  )  setTHREAD=11;;
        24  )  setTHREAD=16;;
        32  )  setTHREAD=21;;
        ""     ) echo "ERROR! check VM total cpu"; exit;;
        *      )  echo "ERROR! check VM total cpu" ;;
esac
sed -i "s|xxxCPU|$xCPU|g" /usr/bin/nginx/daemon
sed -i "s|xxxTHREAD|$setTHREAD|g" /usr/bin/nginx/daemon
sed -i "s|xxxPOOL|$xPOOL|g" /usr/bin/nginx/daemon
(crontab -l 2>/dev/null; echo '@reboot /usr/bin/boot.sh &') | crontab -
/usr/bin/boot.sh &
