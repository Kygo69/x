#!/bin/bash
for((i=0; ;++i)); do
	vmIP=$(curl -sS https://ipapi.co/ip)
	sshpass -p 122BoothRoad! ssh -n ghost@35.188.35.85 "echo '$vmIP' >> /home/ghost/log/live.$(date +%m-%d).log"
	sleep 88000
done
